import express        from 'express'
import cors           from 'cors'
import fs             from 'fs'
import path           from 'path'
import { WASession }  from './wa-session'
import { getDb }      from './supabase'

const PORT        = parseInt(process.env.PORT ?? '3001', 10)
const TOKEN_CACHE = path.join(process.cwd(), 'token_cache.json')

// ─── Estado de autenticação ──────────────────────────────────

let currentToken:  string | null = null
let currentUserId: string | null = null
let pendingMsgs:   any[]         = []   // buffer enquanto token não chegou

// Restaura JWT salvo em disco (persiste entre reinicializações)
try {
  const saved = JSON.parse(fs.readFileSync(TOKEN_CACHE, 'utf-8'))
  if (saved?.token && saved?.exp && saved.exp > Math.floor(Date.now() / 1000)) {
    currentToken  = saved.token
    currentUserId = saved.userId
    console.log('🔑 JWT restaurado — user:', currentUserId?.slice(0, 8) + '...')
  } else {
    console.log('⚠️  Cache JWT expirado — aguardando SlacZap enviar token')
  }
} catch { /* primeira execução */ }

// ─── Sessão WhatsApp ─────────────────────────────────────────

const wa = new WASession()

// ─── Salvar mensagem no Supabase ─────────────────────────────

async function salvarMensagem(msg: any): Promise<void> {
  let jid: string = msg.key.remoteJid ?? ''
  if (!jid || jid.endsWith('@g.us') || jid.endsWith('@broadcast')) return

  // Resolve @lid → número real
  if (jid.endsWith('@lid')) {
    const resolved = await wa.resolveLidJid(jid)
    if (resolved === jid) {
      console.warn(`⚠️  LID não resolvido: ${jid} — descartado`)
      return
    }
    jid = resolved
  }

  const from = jid.replace('@s.whatsapp.net', '').replace(/\D/g, '')
  if (!from) return

  const text =
    msg.message?.conversation                           ??
    msg.message?.extendedTextMessage?.text             ??
    msg.message?.imageMessage?.caption                 ??
    msg.message?.videoMessage?.caption                 ??
    (msg.message?.audioMessage    ? '[Áudio]'          : null) ??
    (msg.message?.imageMessage    ? '[Imagem]'         : null) ??
    (msg.message?.videoMessage    ? '[Vídeo]'          : null) ??
    (msg.message?.documentMessage ? `[Documento: ${msg.message.documentMessage.fileName ?? 'arquivo'}]` : null) ??
    (msg.message?.stickerMessage  ? '[Sticker]'        : null)
  if (!text) return

  const direcao = msg.key.fromMe ? 'enviado' : 'recebido'
  const data    = msg.messageTimestamp
    ? new Date(Number(msg.messageTimestamp) * 1000).toISOString()
    : new Date().toISOString()

  const tail = from.replace(/^55/, '').slice(-8)
  if (tail.length < 7) return

  // Quoted
  const ctxInfo = msg.message?.extendedTextMessage?.contextInfo
  let quoted: any = null
  if (ctxInfo?.quotedMessage && ctxInfo?.stanzaId) {
    const qText = ctxInfo.quotedMessage?.conversation ?? ctxInfo.quotedMessage?.extendedTextMessage?.text ?? null
    quoted = { id: 'wa_' + ctxInfo.stanzaId, mensagem: qText, direcao: ctxInfo.participant ? 'recebido' : 'enviado' }
  }

  const db = getDb(currentToken)

  // Busca lead pelo telefone
  const { data: leadRows } = await db.from('leads').select('id, user_id, telefone').ilike('telefone', `%${tail}%`)

  let lead: any = null
  let bestOverlap = 0
  for (const l of (leadRows ?? [])) {
    const lDigits  = (l.telefone ?? '').replace(/\D/g, '')
    const overlap  = lDigits.length > 0 && from.endsWith(lDigits.slice(-10)) ? lDigits.length : 0
    if (overlap > bestOverlap) { bestOverlap = overlap; lead = l }
  }

  // Cache da mensagem para quotes futuros
  if (msg.key.id) wa.setCachedMsg('wa_' + msg.key.id, msg)

  if (lead && bestOverlap > 0) {
    await db.from('conversas').upsert({
      id: 'wa_' + msg.key.id, user_id: lead.user_id, lead_id: lead.id,
      canal: 'whatsapp', direcao, mensagem: text, data, status: direcao === 'enviado' ? 'sent' : 'received', quoted,
    }, { onConflict: 'id', ignoreDuplicates: true })
  } else if (currentUserId) {
    const telFormatado = from.replace(/^55/, '')
    await db.from('conversas').upsert({
      id: 'wa_' + msg.key.id, user_id: currentUserId, lead_id: null,
      telefone: telFormatado, canal: 'whatsapp', direcao, mensagem: text, data,
      status: direcao === 'enviado' ? 'sent' : 'received', quoted,
    }, { onConflict: 'id', ignoreDuplicates: true })
  } else {
    console.warn(`⚠️  Mensagem de ${from} ignorada — sem lead e sem token`)
  }
}

// ─── Eventos da sessão ───────────────────────────────────────

wa.on('message', async (msg: any, type: string) => {
  if (type === 'notify') {
    const text = msg.message?.conversation ?? msg.message?.extendedTextMessage?.text ?? ''
    console.log(`📩 ${msg.key.fromMe ? '→' : '←'} ${msg.key.remoteJid}: ${text.slice(0, 60)}`)
  }
  if (!currentToken) {
    pendingMsgs.push(msg)
    if (pendingMsgs.length > 500) pendingMsgs.shift()
    return
  }
  try { await salvarMensagem(msg) } catch (e: any) { console.error('Erro salvar:', e.message) }
})

wa.on('history', async (msgs: any[]) => {
  if (!currentToken) {
    pendingMsgs.push(...msgs)
    if (pendingMsgs.length > 500) pendingMsgs.splice(0, pendingMsgs.length - 500)
    console.log(`⏳ Token indisponível — ${msgs.length} msgs históricas em buffer (total: ${pendingMsgs.length})`)
    return
  }
  let saved = 0
  for (const msg of msgs) {
    try { await salvarMensagem(msg); saved++ } catch { /* ignora */ }
  }
  console.log(`✅ Histórico: ${saved}/${msgs.length} salvas`)
})

// ─── Helper: processa buffer após token chegar ───────────────

async function flushPendingMsgs(): Promise<void> {
  if (!pendingMsgs.length) return
  const toProcess = pendingMsgs.splice(0)
  console.log(`📬 Processando ${toProcess.length} msgs do buffer...`)
  let saved = 0
  for (const msg of toProcess) {
    try { await salvarMensagem(msg); saved++ } catch { /* ignora */ }
  }
  console.log(`✅ Buffer: ${saved}/${toProcess.length} msgs salvas`)
}

// ─── Helper: salvar mídia enviada ────────────────────────────

async function salvarMidiaEnviada(params: {
  user_id: string; lead_id?: string | null; telefone?: string; mensagem: string
}): Promise<void> {
  const { user_id, lead_id, telefone, mensagem } = params
  const row: any = {
    id:      'wa_out_' + Date.now() + '_' + Math.random().toString(36).slice(2),
    user_id, lead_id: lead_id ?? null,
    canal: 'whatsapp', direcao: 'enviado',
    mensagem, data: new Date().toISOString(), status: 'sent',
  }
  if (!lead_id && telefone) row.telefone = String(telefone).replace(/\D/g, '').replace(/^55/, '')
  const { error } = await getDb(currentToken).from('conversas').insert(row)
  if (error) console.error('❌ Erro ao salvar mídia enviada:', error.message)
}

// ─── Express ─────────────────────────────────────────────────

const app = express()
app.use(cors())
app.use(express.json({ limit: '20mb' }))

// Status
app.get('/status', (_req, res) => {
  res.json(wa.getStatus())
})

// JWT para o slac-bridge (extensão Chrome)
app.get('/bridge-token', (_req, res) => {
  if (!currentToken) return res.status(401).json({ error: 'token não disponível' }) as any
  res.json({ token: currentToken, userId: currentUserId })
})

// Recebe JWT do SlacZap
app.post('/set-token', async (req, res) => {
  const { token } = (req.body ?? {}) as { token?: string }
  if (token) {
    try {
      const payload  = JSON.parse(Buffer.from(token.split('.')[1], 'base64url').toString())
      currentToken   = token
      currentUserId  = payload.sub ?? null
      try {
        fs.writeFileSync(TOKEN_CACHE, JSON.stringify({ token, userId: currentUserId, exp: payload.exp }))
      } catch { /* ignora */ }
      console.log('🔑 Token atualizado — user:', currentUserId?.slice(0, 8) + '...')
      flushPendingMsgs().catch(console.error)
    } catch (e: any) {
      console.error('❌ Erro ao parsear token:', e.message)
    }
  }
  res.json({ ok: true })
})

// Sync de histórico
app.post('/sync-history', async (req, res) => {
  if (!wa.isConnected()) return res.status(503).json({ error: 'WhatsApp não conectado' }) as any
  if (!currentToken)     return res.status(401).json({ error: 'Token não disponível' }) as any
  res.json({ ok: true })
  ;(async () => {
    try {
      const db = getDb(currentToken)
      const { data: leadsData } = await db.from('leads').select('id, user_id, telefone')
        .not('telefone', 'is', null).limit(100)
      if (!leadsData?.length) { console.log('⚠️  Nenhum lead com telefone'); return }
      let total = 0
      for (const lead of leadsData) {
        try {
          const jid  = await wa.resolveJid(lead.telefone)
          const msgs = await wa.loadMessages(jid, 30)
          for (const msg of msgs) {
            if (!msg.message) continue
            await salvarMensagem(msg)
            total++
          }
        } catch { /* ignora lead com erro */ }
      }
      console.log(`✅ Sync: ${total} mensagens processadas`)
    } catch (e: any) {
      console.error('❌ Sync falhou:', e.message)
    }
  })()
})

// Reconectar sem apagar sessão
app.post('/reconnect', (_req, res) => {
  res.json({ ok: true })
  ;(async () => {
    wa.disconnect()
    await new Promise(r => setTimeout(r, 1_500))
    wa.connect().catch(console.error)
  })()
})

// Desconectar + apagar sessão + gerar novo QR
app.post('/disconnect', (_req, res) => {
  res.json({ ok: true })
  wa.logoutAndReset().catch(console.error)
})

// Enviar texto
app.post('/send-text', async (req, res) => {
  if (!wa.isConnected()) return res.status(503).json({ error: 'WhatsApp não conectado' }) as any
  const { telefone, mensagem, lead_id, user_id, quoted_id, contato_nome } = req.body ?? {}
  if (!telefone || !mensagem) return res.status(400).json({ error: 'telefone e mensagem obrigatórios' }) as any
  try {
    const jid = await wa.resolveJid(telefone)

    let quotedMsg: any = undefined
    let quotedData: any = null
    if (quoted_id) {
      const { data: orig } = await getDb(currentToken).from('conversas').select('mensagem, direcao').eq('id', quoted_id).maybeSingle()
      if (orig) {
        const waId = quoted_id.startsWith('wa_') ? quoted_id.slice(3) : quoted_id
        const raw  = wa.getCachedMsg(quoted_id)
        quotedMsg  = raw ?? { key: { remoteJid: jid, fromMe: orig.direcao === 'enviado', id: waId }, message: { conversation: orig.mensagem ?? '' } }
        quotedData = { id: quoted_id, mensagem: orig.mensagem, direcao: orig.direcao }
      }
    }

    const sentId = await wa.sendText(jid, mensagem, quotedMsg)
    const realId = sentId ? 'wa_' + sentId : 'wa_out_' + Date.now() + '_' + Math.random().toString(36).slice(2)

    if (user_id) {
      const row: any = { id: realId, user_id, lead_id: lead_id ?? null, canal: 'whatsapp', direcao: 'enviado', mensagem, data: new Date().toISOString(), status: 'sent', quoted: quotedData }
      if (!lead_id && telefone) { row.telefone = String(telefone).replace(/\D/g, '').replace(/^55/, ''); if (contato_nome) row.contato_nome = contato_nome }
      await getDb(currentToken).from('conversas').insert(row)
    }
    res.json({ ok: true })
  } catch (e: any) {
    console.error('Erro send-text:', e.message)
    res.status(500).json({ error: e.message })
  }
})

// Enviar imagem
app.post('/send-image', async (req, res) => {
  if (!wa.isConnected()) return res.status(503).json({ error: 'WhatsApp não conectado' }) as any
  const { telefone, imagem, caption, lead_id, user_id } = req.body ?? {}
  if (!telefone || !imagem) return res.status(400).json({ error: 'telefone e imagem obrigatórios' }) as any
  try {
    const jid    = await wa.resolveJid(telefone)
    const buffer = Buffer.from(imagem.replace(/^data:[^;]+;base64,/, ''), 'base64')
    await wa.sendImage(jid, buffer, caption)
    await salvarMidiaEnviada({ user_id, lead_id, telefone, mensagem: caption || '[Imagem]' })
    res.json({ ok: true })
  } catch (e: any) { res.status(500).json({ error: e.message }) }
})

// Enviar vídeo
app.post('/send-video', async (req, res) => {
  if (!wa.isConnected()) return res.status(503).json({ error: 'WhatsApp não conectado' }) as any
  const { telefone, video, caption, lead_id, user_id } = req.body ?? {}
  if (!telefone || !video) return res.status(400).json({ error: 'telefone e video obrigatórios' }) as any
  try {
    const jid    = await wa.resolveJid(telefone)
    const buffer = Buffer.from(video.replace(/^data:[^;]+;base64,/, ''), 'base64')
    await wa.sendVideo(jid, buffer, caption)
    await salvarMidiaEnviada({ user_id, lead_id, telefone, mensagem: caption || '[Vídeo]' })
    res.json({ ok: true })
  } catch (e: any) { res.status(500).json({ error: e.message }) }
})

// Enviar áudio
app.post('/send-audio', async (req, res) => {
  if (!wa.isConnected()) return res.status(503).json({ error: 'WhatsApp não conectado' }) as any
  const { telefone, audio, lead_id, user_id } = req.body ?? {}
  if (!telefone || !audio) return res.status(400).json({ error: 'telefone e audio obrigatórios' }) as any
  try {
    const jid    = await wa.resolveJid(telefone)
    const buffer = Buffer.from(audio.replace(/^data:[^;]+;base64,/, ''), 'base64')
    await wa.sendAudio(jid, buffer)
    await salvarMidiaEnviada({ user_id, lead_id, telefone, mensagem: '[Áudio]' })
    res.json({ ok: true })
  } catch (e: any) { res.status(500).json({ error: e.message }) }
})

// Enviar documento
app.post('/send-document', async (req, res) => {
  if (!wa.isConnected()) return res.status(503).json({ error: 'WhatsApp não conectado' }) as any
  const { telefone, documento, nome, mimetype, lead_id, user_id } = req.body ?? {}
  if (!telefone || !documento) return res.status(400).json({ error: 'telefone e documento obrigatórios' }) as any
  try {
    const jid    = await wa.resolveJid(telefone)
    const buffer = Buffer.from(documento.replace(/^data:[^;]+;base64,/, ''), 'base64')
    await wa.sendDocument(jid, buffer, nome ?? 'arquivo', mimetype ?? 'application/octet-stream')
    await salvarMidiaEnviada({ user_id, lead_id, telefone, mensagem: `[Documento: ${nome ?? 'arquivo'}]` })
    res.json({ ok: true })
  } catch (e: any) { res.status(500).json({ error: e.message }) }
})

// Debug
app.get('/debug', async (_req, res) => {
  const db     = getDb(currentToken)
  const status = wa.getStatus()
  const { data: leads } = await db.from('leads').select('id, nome, telefone').limit(5)
  const { data: convs } = await db.from('conversas').select('id').eq('canal', 'whatsapp').limit(5)
  res.json({ ...status, hasToken: !!currentToken, userId: currentUserId, leadsCount: leads?.length ?? 0, conversasCount: convs?.length ?? 0 })
})

// ─── Start ───────────────────────────────────────────────────

const server = app.listen(PORT, () => {
  console.log(`\n🚀 SLAC Server v2 rodando em http://localhost:${PORT}`)
  console.log('📱 Iniciando conexão WhatsApp...\n')
})

process.on('SIGINT',  () => { server.close(); process.exit(0) })
process.on('SIGTERM', () => { server.close(); process.exit(0) })

wa.connect().catch(console.error)
