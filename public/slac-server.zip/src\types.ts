export type WAStatus = 'disconnected' | 'connecting' | 'qr_pending' | 'connected'

export interface QrImages {
  dark:  string   // PNG base64 — verde sobre preto (dark mode)
  light: string   // PNG base64 — escuro sobre branco (light mode)
}
