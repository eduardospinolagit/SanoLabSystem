/**
 * wa-session.ts
 *
 * Conexão Baileys single-user para o SLAC.
 * Baseado no WASession do Sano.ia com adições do slac-beta:
 *  - QR em base64 dark/light para o frontend
 *  - Mapa LID → JID (arquivo + contacts.upsert)
 *  - Retry queue persistente em disco
 *  - Logger silencioso
 *  - Reconexão controlada (não reconecta em logout/sessão substituída)
 */

import path         from 'path'
import fs           from 'fs'
import { EventEmitter } from 'events'
import QRCode       from 'qrcode'
import qrTerminal   from 'qrcode-terminal'
import type { QrImages, WAStatus } from './types'

const AUTH_DIR      = path.join(process.cwd(), 'auth_info')
const MSG_CACHE_MAX = 300

interface PendingMsg { phone: string; text: string; waJid?: string }

export class WASession extends EventEmitter {
  private socket:        any | null = null
  private status:        WAStatus   = 'disconnected'
  private qrRaw:         string | null = null
  private qrImages:      QrImages | null = null
  private msgCache =     new Map<string, any>()
  private autoReconnect  = false
  private retryQueue:    PendingMsg[] = []
  readonly lidToJid =    new Map<string, string>()

  constructor() {
    super()
    this.loadRetryQueue()
    this.loadLidCache()
  }

  // ─── Conexão ────────────────────────────────────────────────

  async connect(): Promise<void> {
    if (this.socket) {
      try { this.socket.end?.(undefined) } catch { /* ignora */ }
      this.socket = null
    }
    this.autoReconnect = true
    this.status = 'connecting'

    const {
      default: makeWASocket,
      useMultiFileAuthState,
      DisconnectReason,
      fetchLatestBaileysVersion,
      Browsers,
    } = await import('@whiskeysockets/baileys') as any

    if (!fs.existsSync(AUTH_DIR)) fs.mkdirSync(AUTH_DIR, { recursive: true })

    const { state: authState, saveCreds } = await useMultiFileAuthState(AUTH_DIR)
    const { version }                     = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
      version,
      auth:                           authState,
      printQRInTerminal:              false,
      logger:                         this._silentLogger(),
      browser:                        Browsers.ubuntu('Chrome'),
      generateHighQualityLinkPreview: false,
      markOnlineOnConnect:            false,
      syncFullHistory:                false,
      fireInitQueries:                true,
      connectTimeoutMs:               60_000,
      keepAliveIntervalMs:            25_000,
      retryRequestDelayMs:            2_000,
      getMessage:                     async () => ({ conversation: '' }),
    })

    this.socket = sock

    sock.ev.on('connection.update', async (update: any) => {
      const { connection, lastDisconnect, qr } = update

      if (qr) {
        this.status  = 'qr_pending'
        this.qrRaw   = qr
        this.qrImages = null
        qrTerminal.generate(qr, { small: true })
        console.log('\n🔲 QR Code gerado — acesse http://localhost:3001 para escanear\n')
        // Gera as duas versões em paralelo (dark/light) — para no erro em silêncio
        Promise.all([
          QRCode.toDataURL(qr, { width: 256, margin: 1, color: { dark: '#22c55e', light: '#0f0f0f' } }),
          QRCode.toDataURL(qr, { width: 256, margin: 1, color: { dark: '#111111', light: '#ffffff' } }),
        ]).then(([dark, light]) => {
          this.qrImages = { dark, light }
        }).catch(() => {})
        this.emit('qr', qr)
      }

      if (connection === 'open') {
        this.status   = 'connected'
        this.qrRaw    = null
        this.qrImages = null
        console.log('✅ WhatsApp conectado!')
        this.emit('connected')
        setTimeout(() => this._flushRetryQueue().catch(console.error), 2_000)
      }

      if (connection === 'close') {
        const code               = lastDisconnect?.error?.output?.statusCode
        const isLoggedOut        = code === DisconnectReason.loggedOut
        const isReplaced         = code === 440
        this.status = 'disconnected'
        this.socket = null
        console.log(`⚠️  Conexão fechada (código ${code}).`)
        this.emit('disconnected', code)

        if (!this.autoReconnect) return

        if (isLoggedOut || isReplaced) {
          this.autoReconnect = false
          console.log(`🔴 Sessão ${isLoggedOut ? 'encerrada (logout)' : 'substituída'} — aguardando nova conexão.`)
          if (isLoggedOut) {
            // Apaga auth para forçar novo QR
            try { fs.rmSync(AUTH_DIR, { recursive: true, force: true }) } catch { /* ignora */ }
          }
          setTimeout(() => this.connect().catch(console.error), 1_500)
        } else {
          const delay = code === 408 ? 3_000 : 5_000
          console.log(`🔄 Reconectando em ${delay / 1000}s...`)
          setTimeout(() => this.connect().catch(console.error), delay)
        }
      }
    })

    sock.ev.on('creds.update', saveCreds)

    // Indexa contatos LID → JID real
    const indexContacts = (contacts: any[]) => {
      let added = 0
      for (const c of contacts) {
        if (c.id && c.lid) {
          this.lidToJid.set(c.lid, c.id)
          this.lidToJid.set(c.lid.split('@')[0], c.id)
          added++
        }
      }
      if (added > 0) console.log(`📒 ${added} contatos LID indexados (total: ${this.lidToJid.size})`)
    }
    sock.ev.on('contacts.upsert', indexContacts)
    sock.ev.on('contacts.update', indexContacts)

    sock.ev.on('messages.upsert', async ({ messages, type }: any) => {
      if (type !== 'notify' && type !== 'append') return
      for (const msg of messages) {
        if (!msg.message) continue
        this.emit('message', msg, type)
      }
    })

    sock.ev.on('messaging-history.set', ({ messages: histMsgs }: any) => {
      const relevant = histMsgs.filter((m: any) => m.message)
      console.log(`📚 Histórico: ${relevant.length} mensagens`)
      this.emit('history', relevant)
    })
  }

  disconnect(): void {
    this.autoReconnect = false
    try { this.socket?.end?.(undefined) } catch { /* ignora */ }
    this.socket = null
    this.status = 'disconnected'
    this.qrRaw  = null
    this.qrImages = null
    console.log('🔌 Desconectado manualmente')
  }

  async logoutAndReset(): Promise<void> {
    this.autoReconnect = false
    try { await this.socket?.logout() } catch { /* ignora */ }
    try { this.socket?.end?.(undefined) } catch { /* ignora */ }
    this.socket = null
    this.status = 'disconnected'
    this.qrRaw  = null
    this.qrImages = null
    try { fs.rmSync(AUTH_DIR, { recursive: true, force: true }) } catch { /* ignora */ }
    console.log('🔴 Sessão encerrada e auth apagado. Gerando novo QR...')
    setTimeout(() => this.connect().catch(console.error), 1_500)
  }

  // ─── Envio ───────────────────────────────────────────────────

  async resolveJid(telefone: string): Promise<string> {
    let tel = String(telefone).replace(/\D/g, '')
    if (!tel.startsWith('55')) tel = '55' + tel

    const variants = new Set<string>([tel])
    if (tel.length === 13) variants.add(tel.slice(0, 4) + tel.slice(5))
    else if (tel.length === 12) variants.add(tel.slice(0, 4) + '9' + tel.slice(4))

    if (!this.socket) return tel + '@s.whatsapp.net'

    for (const v of variants) {
      const jid = v + '@s.whatsapp.net'
      try {
        const [result] = await this.socket.onWhatsApp(jid)
        if (result?.exists) {
          if (v !== tel) console.log(`📱 JID ajustado: ${tel} → ${v}`)
          return result.jid || jid
        }
      } catch { /* ignora, tenta próxima */ }
    }
    return tel + '@s.whatsapp.net'
  }

  async resolveLidJid(jid: string): Promise<string> {
    if (!jid.endsWith('@lid')) return jid
    const cached = this.lidToJid.get(jid) || this.lidToJid.get(jid.split('@')[0])
    if (cached) return cached
    if (this.socket) {
      try {
        const results = await this.socket.onWhatsApp(jid)
        const resolved = results?.[0]
        if (resolved?.jid?.endsWith('@s.whatsapp.net')) {
          this.lidToJid.set(jid, resolved.jid)
          console.log(`🔗 LID resolvido: ${jid} → ${resolved.jid}`)
          return resolved.jid
        }
      } catch { /* ignora */ }
    }
    return jid
  }

  async sendText(jid: string, text: string, quotedMsg?: any): Promise<string> {
    this._assertConnected()
    const opts: any = quotedMsg ? { quoted: quotedMsg } : {}
    const sent = await this.socket.sendMessage(jid, { text }, opts)
    return sent?.key?.id ?? ''
  }

  async sendImage(jid: string, buffer: Buffer, caption = ''): Promise<void> {
    this._assertConnected()
    await this.socket.sendMessage(jid, { image: buffer, caption })
  }

  async sendVideo(jid: string, buffer: Buffer, caption = ''): Promise<void> {
    this._assertConnected()
    await this.socket.sendMessage(jid, { video: buffer, caption })
  }

  async sendAudio(jid: string, buffer: Buffer): Promise<void> {
    this._assertConnected()
    await this.socket.sendMessage(jid, { audio: buffer, ptt: true, mimetype: 'audio/ogg; codecs=opus' })
  }

  async sendDocument(jid: string, buffer: Buffer, fileName: string, mimetype: string): Promise<void> {
    this._assertConnected()
    await this.socket.sendMessage(jid, { document: buffer, fileName, mimetype })
  }

  async loadMessages(jid: string, count = 30): Promise<any[]> {
    if (!this.socket) return []
    try {
      const result = await this.socket.loadMessages(jid, count, undefined)
      return result?.messages ?? []
    } catch { return [] }
  }

  // ─── Status ──────────────────────────────────────────────────

  getStatus() {
    return {
      connected:    this.status === 'connected',
      hasQr:        this.status === 'qr_pending' && !!this.qrRaw,
      qrImage:      this.qrImages?.dark  ?? null,
      qrImageLight: this.qrImages?.light ?? null,
    }
  }

  isConnected() { return this.status === 'connected' && !!this.socket }

  getCachedMsg(id: string): any { return this.msgCache.get(id) }

  setCachedMsg(id: string, msg: any): void {
    if (this.msgCache.size >= MSG_CACHE_MAX) {
      const first = this.msgCache.keys().next().value
      if (first !== undefined) this.msgCache.delete(first)
    }
    this.msgCache.set(id, msg)
  }

  // ─── Retry queue ─────────────────────────────────────────────

  queueForRetry(phone: string, text: string, waJid?: string): void {
    this.retryQueue.push({ phone, text, waJid })
    this._saveRetryQueue()
    console.log(`⏳ Mensagem enfileirada para reenvio (${this.retryQueue.length} pendente(s))`)
  }

  private async _flushRetryQueue(): Promise<void> {
    if (!this.retryQueue.length) return
    const queue = [...this.retryQueue]
    this.retryQueue = []
    this._saveRetryQueue()
    console.log(`📬 Reenviando ${queue.length} mensagem(ns) pendente(s)...`)
    for (const item of queue) {
      try {
        const jid = item.waJid ?? await this.resolveJid(item.phone)
        await this.sendText(jid, item.text)
      } catch {
        this.retryQueue.push(item)
      }
    }
    if (this.retryQueue.length) this._saveRetryQueue()
  }

  private _saveRetryQueue(): void {
    try {
      if (!fs.existsSync(AUTH_DIR)) return
      fs.writeFileSync(path.join(AUTH_DIR, 'retry_queue.json'), JSON.stringify(this.retryQueue))
    } catch { /* ignora */ }
  }

  private loadRetryQueue(): void {
    try {
      const file = path.join(AUTH_DIR, 'retry_queue.json')
      if (fs.existsSync(file)) {
        const data = JSON.parse(fs.readFileSync(file, 'utf-8'))
        if (Array.isArray(data) && data.length > 0) {
          this.retryQueue = data
          console.log(`📬 ${this.retryQueue.length} mensagem(ns) pendente(s) carregada(s) do disco`)
        }
      }
    } catch { /* ignora */ }
  }

  // ─── LID cache ───────────────────────────────────────────────

  private loadLidCache(): void {
    try {
      if (!fs.existsSync(AUTH_DIR)) return
      const files = fs.readdirSync(AUTH_DIR).filter(f => f.startsWith('lid-mapping-') && f.endsWith('_reverse.json'))
      for (const f of files) {
        try {
          const lid   = f.replace('lid-mapping-', '').replace('_reverse.json', '')
          const phone = JSON.parse(fs.readFileSync(path.join(AUTH_DIR, f), 'utf-8'))
          if (phone && typeof phone === 'string') {
            const jid = phone + '@s.whatsapp.net'
            this.lidToJid.set(lid + '@lid', jid)
            this.lidToJid.set(lid, jid)
          }
        } catch { /* ignora */ }
      }
      if (this.lidToJid.size > 0) console.log(`📒 ${this.lidToJid.size} contatos LID carregados do cache`)
    } catch { /* ignora */ }
  }

  // ─── Helpers ─────────────────────────────────────────────────

  private _assertConnected(): void {
    if (!this.isConnected()) throw new Error('WhatsApp não está conectado')
  }

  private _silentLogger(): any {
    const noop = () => {}
    const stub: any = { level: 'silent', trace: noop, debug: noop, info: noop, warn: noop, error: noop, fatal: noop }
    stub.child = () => this._silentLogger()
    return stub
  }
}
