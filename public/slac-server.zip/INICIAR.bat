@echo off
chcp 65001 >nul
title SLAC WhatsApp Server

echo.
echo  ╔══════════════════════════════════════╗
echo  ║      SLAC WhatsApp Server v2         ║
echo  ╚══════════════════════════════════════╝
echo.

:: Verifica se Node.js está instalado
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo  [!] Node.js não encontrado no seu computador.
    echo.
    echo  Vamos instalar agora. Siga os passos:
    echo   1. Clique em "Next" em todas as telas
    echo   2. Marque "Add to PATH" se aparecer
    echo   3. Após instalar, FECHE esta janela e abra o INICIAR.bat novamente
    echo.
    pause
    start https://nodejs.org/dist/v20.19.1/node-v20.19.1-x64.msi
    echo  Abrindo instalador do Node.js...
    pause
    exit
)

:: Node encontrado
for /f "tokens=*" %%i in ('node -v') do set NODE_VER=%%i
echo  [✓] Node.js %NODE_VER% encontrado.
echo.

:: Instala dependências se node_modules não existir
if not exist "node_modules\" (
    echo  [→] Instalando dependências pela primeira vez...
    echo      (isso leva ~1 minuto, só acontece uma vez)
    echo.
    call npm install
    if %errorlevel% neq 0 (
        echo.
        echo  [!] Erro ao instalar dependências. Verifique sua conexão com a internet.
        pause
        exit
    )
    echo.
    echo  [✓] Dependências instaladas!
    echo.
)

:: Inicia o servidor
echo  [→] Iniciando servidor WhatsApp...
echo  [i] Mantenha esta janela aberta enquanto usar o SlacZap.
echo  [i] Para parar: feche esta janela ou pressione Ctrl+C
echo.
echo ──────────────────────────────────────────
echo.

node_modules\.bin\tsx src\index.ts

echo.
echo  Servidor encerrado.
pause
