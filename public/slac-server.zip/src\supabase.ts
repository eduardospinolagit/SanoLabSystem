import { createClient } from '@supabase/supabase-js'

const SB_URL  = 'https://jqmnmudfxxdcjfradvcj.supabase.co'
const SB_ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpxbW5tdWRmeHhkY2pmcmFkdmNqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQwNDAxNTMsImV4cCI6MjA4OTYxNjE1M30.LKZz_djPhIc_PvdLxAAhLaV-BZxX70nGup-qODIDEF4'

export const sbAnon = createClient(SB_URL, SB_ANON)

// Retorna cliente autenticado com JWT do usuário (necessário pelo RLS)
export function getDb(token?: string | null) {
  if (!token) return sbAnon
  return createClient(SB_URL, SB_ANON, {
    global: { headers: { Authorization: `Bearer ${token}` } },
    auth:   { persistSession: false, autoRefreshToken: false },
  })
}
